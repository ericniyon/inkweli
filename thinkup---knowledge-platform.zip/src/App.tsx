/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowRight,
  Target,
  Search,
  Menu,
  Filter
} from 'lucide-react';

interface Article {
  id: string;
  title: string;
  date: string;
  author: string;
  category: string;
  image: string;
  excerpt: string;
  content: string;
}

const ARTICLES: Article[] = [
  {
    id: '1',
    title: 'Nationalism & The Myth of African Unity',
    date: 'Feb 18, 2026',
    author: 'Dr. Amara Okafor',
    category: 'POLITICS',
    image: 'https://picsum.photos/seed/p1/400/400',
    excerpt: 'Exploring the historical roots and modern challenges of pan-Africanism.',
    content: 'The concept of pan-Africanism has long been a cornerstone of political discourse across the continent. However, as we navigate the complexities of the 21st century, the tension between national sovereignty and collective unity has never been more apparent. This deep dive examines how historical colonial boundaries continue to influence modern diplomatic relations and why the dream of a truly unified Africa remains elusive yet essential for global leverage.'
  },
  {
    id: '2',
    title: "Kinshasa's Bad Behavior Should not be Emboldened",
    date: 'Feb 18, 2026',
    author: 'Jean-Pierre Bakole',
    category: 'POLITICS',
    image: 'https://picsum.photos/seed/p2/400/400',
    excerpt: 'A critical analysis of the current administration in the DRC.',
    content: 'The ongoing political instability in the Democratic Republic of Congo (DRC) raises significant questions about international accountability. Recent actions by the administration in Kinshasa have sparked concerns among regional neighbors and global observers alike. We analyze the socio-economic impact of these policies and argue for a more robust international framework that prioritizes democratic integrity over short-term geopolitical stability.'
  },
  {
    id: '3',
    title: 'With Every False Accusation, Kagame is Paying the Price for Standing Tall',
    date: 'Feb 18, 2026',
    author: 'Eric Niyomugabo',
    category: 'POLITICS',
    image: 'https://picsum.photos/seed/p3/400/400',
    excerpt: 'How Rwanda\'s leadership navigates external pressures.',
    content: 'Rwanda\'s remarkable transformation over the last three decades is often met with both admiration and intense scrutiny. President Paul Kagame\'s leadership style, characterized by a focus on efficiency and self-reliance, has frequently put him at odds with traditional Western developmental models. This article explores the narrative of "standing tall" in the face of international criticism and what it means for the future of African self-determination.'
  },
  {
    id: '4',
    title: 'In Understanding the DRC Security Crisis, Distance is a Factor',
    date: 'Feb 18, 2026',
    author: 'Sarah Jenkins',
    category: 'POLITICS',
    image: 'https://picsum.photos/seed/p4/400/400',
    excerpt: 'Examining how geographical vastness complicates security efforts.',
    content: 'The sheer scale of the DRC presents a unique set of security challenges that are often overlooked in global analysis. From the dense forests of the east to the bustling streets of Kinshasa, the logistical nightmare of maintaining order across such a vast territory cannot be overstated. We look at how "distance" acts as a physical and psychological barrier to effective governance and peace-keeping operations.'
  },
  {
    id: '5',
    title: 'The Future of GTM Strategies in Emerging Markets',
    date: 'Feb 20, 2026',
    author: 'Marcus Thorne',
    category: 'BUSINESS (GTM)',
    image: 'https://picsum.photos/seed/b1/400/400',
    excerpt: 'Why traditional playbooks fail in high-growth developing economies.',
    content: 'Entering an emerging market requires more than just a translated marketing campaign. Companies that succeed are those that understand the local nuances of distribution, consumer trust, and regulatory hurdles. We break down the "GTM 2.0" framework, focusing on hyper-localization and the shift from transactional relationships to ecosystem building in markets like Nigeria, Vietnam, and Brazil.'
  },
  {
    id: '6',
    title: 'Supply Chain Resilience: Lessons from the Last Decade',
    date: 'Feb 22, 2026',
    author: 'Elena Rodriguez',
    category: 'BUSINESS (GTM)',
    image: 'https://picsum.photos/seed/b2/400/400',
    excerpt: 'How global volatility is forcing companies to rethink sourcing.',
    content: 'The era of "just-in-time" manufacturing is giving way to "just-in-case" resilience. Following a decade of unprecedented global disruptions, from pandemics to trade wars, businesses are fundamentally restructuring their supply chains. This analysis highlights the move toward "near-shoring" and the critical role of AI-driven predictive analytics in mitigating future risks.'
  }
];

const CATEGORIES = ['ALL', 'BUSINESS (GTM)', 'POLITICS', 'TECHNOLOGY', 'CULTURE'];

const ThinkUpLogo = ({ className = "w-6 h-6", iconOnly = false }: { className?: string; iconOnly?: boolean }) => (
  <div className={`flex items-center gap-2 ${className}`}>
    <svg width="32" height="32" viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg" className="flex-shrink-0">
      <path d="M25 45V65C25 84.33 40.67 100 60 100C79.33 100 95 84.33 95 65V50" stroke="currentColor" strokeWidth="12" strokeLinecap="round" />
      <path d="M85 60L95 50L105 60" stroke="currentColor" strokeWidth="12" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="60" cy="65" r="10" fill="#6366f1" />
      <rect x="56" y="20" width="8" height="25" rx="4" fill="#818cf8" />
    </svg>
    {!iconOnly && <span className="font-bold text-lg tracking-tight">ThinkUp</span>}
  </div>
);

export default function App() {
  const [view, setView] = useState<'HOME' | 'WRITER' | 'ARTICLE_DETAILS'>('HOME');
  const [selectedArticleId, setSelectedArticleId] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState('ALL');
  const [expandedArticleId, setExpandedArticleId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isApplicationModalOpen, setIsApplicationModalOpen] = useState(false);

  const filteredArticles = ARTICLES
    .filter(article => {
      const matchesCategory = activeCategory === 'ALL' || article.category === activeCategory;
      const matchesSearch = 
        article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        article.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
        article.content.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });

  const toggleExpand = (id: string) => {
    setExpandedArticleId(expandedArticleId === id ? null : id);
  };

  const navigateToHome = () => {
    setView('HOME');
    setActiveCategory('ALL');
    setExpandedArticleId(null);
    setSelectedArticleId(null);
    setSearchQuery('');
    window.scrollTo(0, 0);
  };

  const navigateToArticle = (id: string) => {
    setSelectedArticleId(id);
    setView('ARTICLE_DETAILS');
    window.scrollTo(0, 0);
  };

  const navigateToWriter = () => {
    setView('WRITER');
    window.scrollTo(0, 0);
  };

  const selectedArticle = ARTICLES.find(a => a.id === selectedArticleId);

  return (
    <div className="min-h-screen flex flex-col bg-white">
      {/* Header */}
      <header className="h-16 px-6 flex items-center justify-between border-b border-gray-100 sticky top-0 bg-white/80 backdrop-blur-md z-50">
        <div className="cursor-pointer flex-shrink-0" onClick={navigateToHome}>
          <ThinkUpLogo />
        </div>
        
        <div className="flex-grow max-w-md mx-8">
          <div className="relative group">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-black transition-colors" size={16} />
            <input 
              type="text"
              placeholder="Search insights..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-gray-50 border border-transparent focus:border-gray-200 focus:bg-white rounded-full py-2 pl-10 pr-4 text-sm outline-none transition-all"
            />
          </div>
        </div>

        <div className="flex items-center gap-2 flex-shrink-0">
          <button className="p-2 hover:bg-gray-50 rounded-full transition-colors lg:hidden">
            <Menu size={18} />
          </button>
          <div className="hidden lg:flex items-center gap-6">
            <button 
              onClick={navigateToWriter}
              className={`text-[10px] font-bold tracking-widest uppercase transition-colors ${view === 'WRITER' ? 'text-accent' : 'text-gray-400 hover:text-black'}`}
            >
              Become a Writer
            </button>
            <button className="text-[10px] font-bold tracking-widest uppercase text-gray-400 hover:text-black transition-colors">Sign In</button>
          </div>
        </div>
      </header>

      <main className="flex-grow">
        <AnimatePresence mode="wait">
          {view === 'HOME' && (
            <motion.div
              key="home"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              {/* Hero Section */}
              <section className="relative pt-32 pb-24 flex flex-col items-center text-center overflow-hidden bg-[#FAFAFA] border-b border-gray-100">
                {/* Background Decorative Elements */}
                <div className="absolute inset-0 -z-10 pointer-events-none">
                  <div className="absolute top-0 left-0 w-full h-full opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(#000 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 0.05, scale: 1 }}
                    transition={{ duration: 2 }}
                    className="absolute -top-24 -left-24 w-96 h-96 bg-accent rounded-full blur-3xl"
                  />
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 0.05, scale: 1 }}
                    transition={{ duration: 2, delay: 0.5 }}
                    className="absolute -bottom-24 -right-24 w-96 h-96 bg-accent rounded-full blur-3xl"
                  />
                </div>

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, ease: "easeOut" }}
                  className="max-w-4xl px-6 relative"
                >
                  <h1 className="medium-title-lg mb-8 leading-[0.9]">
                    ThinkUp<span className="text-accent">.</span>
                  </h1>
                  
                  <p className="text-xl md:text-2xl font-serif text-gray-500 max-w-2xl mx-auto leading-relaxed italic">
                    "Knowledge that Wins You Markets"
                  </p>
                </motion.div>

                {/* Floating Elements for visual interest */}
                <div className="absolute inset-0 pointer-events-none overflow-hidden">
                  <motion.div 
                    animate={{ y: [0, -20, 0], rotate: [0, 10, 0] }}
                    transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
                    className="absolute left-[10%] top-[20%] text-gray-100"
                  >
                    <Target size={120} strokeWidth={0.5} />
                  </motion.div>
                  <motion.div 
                    animate={{ y: [0, 20, 0], rotate: [0, -10, 0] }}
                    transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
                    className="absolute right-[10%] bottom-[20%] text-gray-100"
                  >
                    <Search size={100} strokeWidth={0.5} />
                  </motion.div>
                </div>
              </section>

        {/* Filters Bar */}
        <div className="max-w-7xl mx-auto px-6 mb-12">
          <div className="flex items-center gap-4 overflow-x-auto no-scrollbar border-b border-gray-100 pb-4">
            <div className="flex-shrink-0 flex items-center gap-2 text-black mr-4">
              <Filter size={14} />
              <span className="text-[10px] font-bold tracking-widest uppercase">Filter</span>
            </div>
            {CATEGORIES.map(cat => (
              <button
                key={cat}
                onClick={() => { setActiveCategory(cat); setExpandedArticleId(null); }}
                className={`flex-shrink-0 px-4 py-2 rounded-full text-[10px] font-bold tracking-widest uppercase transition-all ${
                  activeCategory === cat 
                    ? 'bg-black text-white shadow-lg shadow-black/10' 
                    : 'text-gray-400 hover:text-black hover:bg-gray-50'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Content Area */}
        <div className="max-w-5xl mx-auto px-6 pb-24 relative">
          {/* Subtle Background Icons for Content Area */}
          <div className="absolute inset-0 -z-10 pointer-events-none overflow-hidden">
            <motion.div 
              animate={{ y: [0, 20, 0] }}
              transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
              className="absolute left-[-10%] top-[10%] text-gray-50 opacity-50"
            >
              <Target size={120} strokeWidth={0.5} />
            </motion.div>
            <motion.div 
              animate={{ y: [0, -20, 0] }}
              transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
              className="absolute right-[-5%] top-[40%] text-gray-50 opacity-50"
            >
              <Search size={100} strokeWidth={0.5} />
            </motion.div>
            <motion.div 
              animate={{ rotate: 360 }}
              transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
              className="absolute left-[5%] bottom-[10%] text-gray-50 opacity-50"
            >
              <Filter size={80} strokeWidth={0.5} />
            </motion.div>
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={activeCategory}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="space-y-16"
            >
              {filteredArticles.length > 0 ? (
                <>
                  {/* Latest News Section */}
                  <div className="space-y-8">
                    <div className="flex items-center gap-4">
                      <h2 className="medium-label">Featured Insight</h2>
                      <div className="h-px flex-grow bg-gray-100" />
                    </div>
                    <div className="grid grid-cols-1 gap-12">
                      {filteredArticles.slice(0, 1).map((article, index) => (
                        <motion.div
                          key={article.id}
                          layout
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.1 }}
                          className="group flex flex-col gap-8 items-start p-0 border-none transition-all"
                        >
                          <div className="flex flex-col md:flex-row gap-8 items-start w-full">
                            <div 
                              onClick={() => navigateToArticle(article.id)}
                              className="relative w-full md:w-1/2 aspect-[16/9] flex-shrink-0 bg-gray-50 rounded-lg overflow-hidden cursor-pointer"
                            >
                              <img 
                                src={article.image} 
                                alt={article.title} 
                                className="w-full h-full object-cover transition-all duration-1000 group-hover:scale-105"
                                referrerPolicy="no-referrer"
                              />
                            </div>
                            <div className="space-y-4 flex-grow">
                              <span className="medium-label text-accent">
                                {article.category}
                              </span>
                              <div className="space-y-3">
                                <h3 
                                  onClick={() => navigateToArticle(article.id)}
                                  className="medium-title-md group-hover:text-accent transition-colors cursor-pointer"
                                >
                                  {article.title}
                                </h3>
                                <div className="flex items-center gap-2 medium-meta">
                                  <span className="text-gray-900 font-semibold">{article.author}</span>
                                  <span className="w-1 h-1 rounded-full bg-gray-300" />
                                  <span>{article.date}</span>
                                </div>
                                <p className="medium-excerpt">
                                  {article.excerpt}
                                </p>
                              </div>
                              <button 
                                onClick={() => navigateToArticle(article.id)}
                                className="medium-label text-black hover:text-accent transition-colors flex items-center gap-2 group/btn"
                              >
                                Read Full Insight
                                <ArrowRight size={12} className="transition-transform group-hover/btn:translate-x-1" />
                              </button>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>

                  {/* Other Articles Section Grouped by Category */}
                  {filteredArticles.length > 1 && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
                      {CATEGORIES.filter(cat => cat !== 'ALL').map(category => {
                        const categoryArticles = filteredArticles.slice(1).filter(a => a.category === category);
                        if (categoryArticles.length === 0) return null;

                        return (
                          <div key={category} className="space-y-8">
                              <div className="flex items-center gap-4">
                                <h2 className="medium-label">{category}</h2>
                                <div className="h-px flex-grow bg-gray-100" />
                              </div>
                            <div className="space-y-4">
                              {categoryArticles.map((article, index) => (
                                <motion.div
                                  key={article.id}
                                  layout
                                  initial={{ opacity: 0, x: 10 }}
                                  animate={{ opacity: 1, x: 0 }}
                                  transition={{ delay: index * 0.05 }}
                                  className="group flex flex-col py-6 border-b border-gray-100 last:border-0 hover:bg-gray-50/30 px-4 -mx-4 transition-colors rounded-xl"
                                >
                                  <div className="flex items-start gap-6 w-full">
                                    <div 
                                      onClick={() => navigateToArticle(article.id)}
                                      className="w-20 h-20 flex-shrink-0 bg-gray-100 rounded-lg overflow-hidden cursor-pointer"
                                    >
                                      <img 
                                        src={article.image} 
                                        alt={article.title} 
                                        className="w-full h-full object-cover transition-all duration-500 group-hover:scale-110"
                                        referrerPolicy="no-referrer"
                                      />
                                    </div>
                                    <div className="flex-grow space-y-2">
                                      <h4 
                                        onClick={() => navigateToArticle(article.id)}
                                        className="medium-title-sm !text-base group-hover:text-accent transition-colors cursor-pointer"
                                      >
                                        {article.title}
                                      </h4>
                                      <div className="flex items-center gap-2 medium-meta">
                                        <span className="text-gray-900">{article.author}</span>
                                        <span className="w-1 h-1 rounded-full bg-gray-300" />
                                        <span>{article.date}</span>
                                      </div>
                                      <p className="medium-excerpt !text-xs line-clamp-2">
                                        {article.excerpt}
                                      </p>
                                    <div className="flex items-center justify-between mt-2">
                                        <button 
                                          onClick={(e) => { e.stopPropagation(); navigateToArticle(article.id); }}
                                          className="medium-label !text-[9px] text-black hover:text-accent transition-colors flex items-center gap-1 group/btn"
                                        >
                                          Read More
                                          <ArrowRight size={10} className="transition-transform group-hover/btn:translate-x-0.5" />
                                        </button>
                                      </div>
                                    </div>
                                  </div>
                                </motion.div>
                              ))}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </>
              ) : (
                <div className="py-24 flex flex-col items-center text-center text-gray-400">
                  <p className="italic text-lg mb-2">No insights found in this category.</p>
                  <button 
                    onClick={() => setActiveCategory('ALL')}
                    className="text-black font-bold text-xs tracking-widest uppercase underline underline-offset-4"
                  >
                    View all insights
                  </button>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
            </motion.div>
          )}

          {view === 'WRITER' && (
            <motion.div
              key="writer"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="max-w-3xl mx-auto px-6 py-24"
            >
              <div className="mb-12">
                <h2 className="medium-title-lg !text-5xl mb-4">Become a ThinkUp Writer</h2>
                <p className="medium-body !text-lg text-gray-500 leading-relaxed">
                  Join our global network of intelligence analysts, business strategists, and political observers. Share your expertise with a community that values deep, actionable knowledge.
                </p>
              </div>

              <div className="space-y-12">
                <section>
                  <h3 className="medium-label mb-6 flex items-center gap-4">
                    <span>Editorial Guidelines</span>
                    <div className="h-px flex-grow bg-gray-100" />
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-3">
                      <h4 className="medium-title-sm !text-sm">Actionable Intelligence</h4>
                      <p className="medium-meta !text-xs leading-relaxed">
                        We don't just report news; we provide insights that help leaders win markets. Every piece should answer "Why does this matter?" and "What should be done?"
                      </p>
                    </div>
                    <div className="space-y-3">
                      <h4 className="medium-title-sm !text-sm">Deep Context</h4>
                      <p className="medium-meta !text-xs leading-relaxed">
                        Avoid surface-level analysis. Connect historical roots to modern challenges. We value expertise that navigates complexity with clarity.
                      </p>
                    </div>
                    <div className="space-y-3">
                      <h4 className="medium-title-sm !text-sm">Objective & Rigorous</h4>
                      <p className="medium-meta !text-xs leading-relaxed">
                        Maintain editorial integrity. Back your claims with data, logical reasoning, and diverse perspectives.
                      </p>
                    </div>
                    <div className="space-y-3">
                      <h4 className="medium-title-sm !text-sm">Concise & Sharp</h4>
                      <p className="medium-meta !text-xs leading-relaxed">
                        Respect our readers' time. Use sharp, active language. Every sentence should earn its place on the page.
                      </p>
                    </div>
                  </div>
                </section>

                <section>
                  <h3 className="medium-label mb-6 flex items-center gap-4">
                    <span>Submission Process</span>
                    <div className="h-px flex-grow bg-gray-100" />
                  </h3>
                  <div className="space-y-6">
                    <div className="flex gap-6 items-start">
                      <div className="w-8 h-8 rounded-full bg-black text-white flex items-center justify-center medium-label !text-white flex-shrink-0">01</div>
                      <div>
                        <h4 className="medium-title-sm !text-sm mb-1">Pitch Your Idea</h4>
                        <p className="medium-meta !text-xs leading-relaxed">Send a 200-word summary of your proposed insight, including why it's timely and what unique perspective you bring.</p>
                      </div>
                    </div>
                    <div className="flex gap-6 items-start">
                      <div className="w-8 h-8 rounded-full bg-black text-white flex items-center justify-center medium-label !text-white flex-shrink-0">02</div>
                      <div>
                        <h4 className="medium-title-sm !text-sm mb-1">Editorial Review</h4>
                        <p className="medium-meta !text-xs leading-relaxed">Our team will review your pitch within 48 hours. If approved, you'll be assigned an editor to work on the full draft.</p>
                      </div>
                    </div>
                    <div className="flex gap-6 items-start">
                      <div className="w-8 h-8 rounded-full bg-black text-white flex items-center justify-center medium-label !text-white flex-shrink-0">03</div>
                      <div>
                        <h4 className="medium-title-sm !text-sm mb-1">Publication</h4>
                        <p className="medium-meta !text-xs leading-relaxed">Once the final draft is polished, your insight will be published across our platform and shared with our global network.</p>
                      </div>
                    </div>
                  </div>
                </section>

                <div className="pt-12 border-t border-gray-100 text-center">
                  <p className="medium-meta !text-sm font-medium mb-6">Ready to share your intelligence?</p>
                  <button 
                    onClick={() => setIsApplicationModalOpen(true)}
                    className="bg-black text-white medium-label !text-white px-8 py-4 rounded-full hover:bg-accent transition-all shadow-xl shadow-black/10"
                  >
                    Apply to Write
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {view === 'ARTICLE_DETAILS' && selectedArticle && (
            <motion.div
              key="details"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="max-w-4xl mx-auto px-6 py-24"
            >
              <button 
                onClick={navigateToHome}
                className="flex items-center gap-2 text-gray-400 hover:text-black transition-colors medium-label mb-12 group"
              >
                <ArrowRight size={16} className="rotate-180 transition-transform group-hover:-translate-x-1" />
                Back to Insights
              </button>

              <article className="space-y-12">
                <div className="space-y-6">
                  <div className="flex items-center gap-4">
                    <span className="medium-label text-accent">{selectedArticle.category}</span>
                    <div className="h-px flex-grow bg-gray-100" />
                  </div>
                  <h1 className="medium-title-lg !text-5xl leading-tight">
                    {selectedArticle.title}
                  </h1>
                  <div className="flex items-center gap-4 medium-meta !text-base">
                    <div className="w-12 h-12 rounded-full bg-gray-100 overflow-hidden">
                      <img src={`https://picsum.photos/seed/${selectedArticle.author}/100/100`} alt="" className="w-full h-full object-cover" />
                    </div>
                    <div>
                      <p className="text-gray-900 font-medium">{selectedArticle.author}</p>
                      <p className="text-gray-400">{selectedArticle.date} · 8 min read</p>
                    </div>
                  </div>
                </div>

                <div className="aspect-[16/9] w-full rounded-3xl overflow-hidden bg-gray-100">
                  <img 
                    src={selectedArticle.image} 
                    alt={selectedArticle.title} 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <div className="medium-body max-w-2xl mx-auto space-y-8">
                  {selectedArticle.content.split('\n\n').map((para, i) => (
                    <p key={i}>{para}</p>
                  ))}
                </div>

                {/* Related Articles in Details Page */}
                <div className="pt-24 border-t border-gray-100">
                  <h2 className="medium-title-md mb-12">More from {selectedArticle.category}</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                    {ARTICLES.filter(a => a.category === selectedArticle.category && a.id !== selectedArticle.id).slice(0, 2).map(related => (
                      <div 
                        key={related.id}
                        onClick={() => navigateToArticle(related.id)}
                        className="group cursor-pointer space-y-4"
                      >
                        <div className="aspect-video rounded-2xl overflow-hidden bg-gray-100">
                          <img src={related.image} alt="" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                        </div>
                        <div className="space-y-2">
                          <h3 className="medium-title-sm group-hover:text-accent transition-colors">{related.title}</h3>
                          <p className="medium-meta">{related.date}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </article>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Application Modal */}
        <AnimatePresence>
          {isApplicationModalOpen && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsApplicationModalOpen(false)}
                className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              />
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl overflow-hidden"
              >
                <div className="p-8 md:p-12">
                  <div className="flex justify-between items-start mb-8">
                    <div>
                      <h3 className="medium-title-md !text-2xl mb-2">Writer Application</h3>
                      <p className="medium-meta">Tell us about your expertise and what you'd like to contribute.</p>
                    </div>
                    <button 
                      onClick={() => setIsApplicationModalOpen(false)}
                      className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                    >
                      <Menu size={20} className="rotate-45" />
                    </button>
                  </div>

                  <form className="space-y-6" onSubmit={(e) => { e.preventDefault(); setIsApplicationModalOpen(false); alert('Application submitted successfully!'); }}>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-1.5">
                        <label className="medium-label">Full Name</label>
                        <input type="text" required className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm outline-none focus:border-black transition-colors" placeholder="John Doe" />
                      </div>
                      <div className="space-y-1.5">
                        <label className="medium-label">Email Address</label>
                        <input type="email" required className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm outline-none focus:border-black transition-colors" placeholder="john@example.com" />
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <label className="medium-label">Area of Expertise</label>
                      <select className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm outline-none focus:border-black transition-colors">
                        {CATEGORIES.filter(c => c !== 'ALL').map(c => <option key={c} value={c}>{c}</option>)}
                        <option value="OTHER">OTHER</option>
                      </select>
                    </div>
                    <div className="space-y-1.5">
                      <label className="medium-label">Your Pitch (200 words)</label>
                      <textarea required rows={4} className="w-full bg-gray-50 border border-gray-100 rounded-xl px-4 py-3 text-sm outline-none focus:border-black transition-colors resize-none" placeholder="What unique insight do you want to share?"></textarea>
                    </div>
                    <button type="submit" className="w-full bg-black text-white medium-label !text-white py-4 rounded-xl hover:bg-accent transition-all shadow-lg shadow-black/10">
                      Submit Application
                    </button>
                  </form>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="py-16 px-6 border-t border-gray-100 flex flex-col items-center text-center bg-gray-50/50">
        <div className="mb-6 cursor-pointer" onClick={navigateToHome}>
          <ThinkUpLogo />
        </div>
        <div className="flex gap-8 mb-8 medium-label">
          <a href="#" className="hover:text-black transition-colors">Twitter</a>
          <a href="#" className="hover:text-black transition-colors">LinkedIn</a>
          <a href="#" className="hover:text-black transition-colors">Newsletter</a>
        </div>
        <p className="text-[10px] font-mono text-gray-300 uppercase tracking-[0.3em]">
          © 2026 ThinkUp Intelligence. All Rights Reserved.
        </p>
      </footer>
    </div>
  );
}
